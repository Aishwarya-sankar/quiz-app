// Check if the user is logged in
if (!localStorage.getItem('username')) {
    // If not logged in, redirect to the login page
    window.location.href = 'index.html'; // Change this to your login page
}


// Handle login form submission
document.getElementById('login')?.addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from submitting
    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;
    console.log('Logging in user:', username, password);
   
    // Here you would typically validate the username and password with your server
    // For now, we'll just redirect to the dashboard
    localStorage.setItem('username', username); // Store username in local storage
    window.location.href = 'dashboard.html'; // Redirect to dashboard
});


// Handle signup form submission
document.getElementById('register')?.addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from submitting
    const email = document.getElementById('email').value;
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    console.log('Registering user:', email, username, password);
   
    // Redirect to user details page with username in local storage
    localStorage.setItem('username', username);
    window.location.href = 'user-details.html';
});


// Populate age dropdown in user-details.html
if (document.getElementById('age')) {
    const ageSelect = document.getElementById('age');
    for (let i = 5; i <= 60; i++) {
        const option = document.createElement('option');
        option.value = i;
        option.textContent = i;
        ageSelect.appendChild(option);
    }
}


// Display username in user-details.html
if (document.getElementById('display-username')) {
    const username = localStorage.getItem('username');
    document.getElementById('display-username').textContent = username;
}


// Handle user details submission
document.getElementById('submit-details')?.addEventListener('click', function() {
    const dob = document.getElementById('dob').value;
    const age = document.getElementById('age').value;
    const role = document.getElementById('role').value;
    console.log('User  Details:', { dob, age, role });
   
    // Here you would typically send the data to your server for further processing


    // Redirect to the dashboard page after submitting user details
    window.location.href = 'dashboard.html';
});
